class Maillon:
    """
    Implémentation d'un Maillon,
    nécessaire à l'implémentation d'une liste chaînée
    """

    def __init__(self, valeur=None, suivant=None):
        """
        Initialisation d'un maillon
        """
        self.valeur = valeur
        self.suivant = suivant

    def __repr__(self):
        """
        Sortie: str - Chaîne d'affichage du maillon.
        """
        return "("+str(self.valeur)+", "+str(self.suivant)+")"


class ListeChainee:
    """
    Implémentation d'une liste chaînée
    """

    def __init__(self):
        """
        Initialisation d'une liste chaînée.
        """
        self.premier = None

    def est_vide(self):
        """
        Booléen indiquant si la liste chaînée est vide
        """
        return self.premier is None

    def inserer_en_tete(self, elt):
        """
        Insère un élément en tête de liste.
        """
        self.premier = Maillon(elt, self.premier)

    def tete(self):
        """
        Renvoie la valeur de l'élément en tête de liste.
        """
        return self.premier.valeur

    def queue(self):
        """
        Renvoie la liste située en queue (pas le maillon !)
        sous la forme d'une nouvelle liste.
        Attention aux effets de bord
        """
        result = ListeChainee()
        if self.premier.suivant is not None:
            result.premier = self.premier.suivant
        return result

    def __repr__(self):
        """
        Sortie: str - Chaîne d'affichage de la liste.
        """
        return str(self.premier)

    def vider(self):
        """"
        Supprime tous les éléments de la liste.
        Ne renvoie rien.
        """
        while not self.est_vide():
            temp = self.premier
            self.premier = temp.suivant
            del temp

    def tab_to_liste(self, tab):
        """
        Insère les éléments de tab dans l'objet ListeChainee
        """
        self.vider()
        for i in range(len(tab)-1, -1, -1):
            self.inserer_en_tete(tab[i])
    
    def inserer_en_dernier(self, elt):
        """
        Insère l'élément en fin de liste chaînée
        """
        if self.est_vide():
            self.inserer_en_tete(elt)
        else:
            temp = self.premier
            while not(temp.suivant is None):
                temp = temp.suivant
            temp.suivant = Maillon(elt)
    
    def supprimer_premier(self):
        """
        Sortie: None - Supprime le premier élément de la liste
        """
        if not self.est_vide() :
            temp = self.premier
            self.premier = temp.suivant
            del temp
    
    def supprimer_dernier(self):
        """
        Sortie: None - Supprime le dernier élément de la liste
        """
        temp = self.premier
        if temp.suivant is None:
            self.supprimer_premier()
        else:
            while temp.suivant.suivant is not None:
                temp = temp.suivant
            temp2 = temp.suivant
            temp.suivant = None
            del temp2
    
    def __len__(self):
        """
        Sortie: int - Nombre d'éléments de la liste
        """
        nb_elt = 0
        temp = self.premier
        while not(temp is None):
            nb_elt += 1
            temp = temp.suivant
        return nb_elt
    
    def elt_indice(self, k):
        """
        k - int, entier tel que 0 <= k < taille
        Sortie: élément d'indice k de la liste
        """
        assert not self.est_vide(), "La liste est vide"
        
        temp = self.premier
        while not(temp.suivant is None) and k > 0:
            temp = temp.suivant
            k = k-1
        assert k==0, "Index out of range"
        return temp.valeur
    
    def modifier_elt_indice(self, k, elt):
        """
        k - int, entier positif inférieur au nombre d'éléments de la liste
        elt - un élément de même type que ceux de la liste
        Sortie: None - Modification de la valeur d'indice k de la liste
        """
        assert not self.est_vide(), "La liste est vide"
        
        temp = self.premier
        while not(temp.suivant is None) and k > 0:
            temp = temp.suivant
            k = k-1
        assert k==0, "Index out of range"
        temp.valeur = elt
    
    def insere_position(self, k, elt):
        """
        k - int, entier positif inférieur au nombre d'éléments de la liste
        elt - un élément de même type que ceux de la liste
        Sortie: None - Insertion de elt à l'indice k
        """
        if k==0:
            self.inserer_en_tete(elt)
        else:
            assert not self.est_vide(), "La liste est vide"
            temp = self.premier
            for i in range(k-1):
                assert temp is not None, "Indice trop grand"
                temp = temp.suivant
                
            new = Maillon(elt, temp.suivant)
            temp.suivant = new
    
    def somme(self):
        """
        Sortie: int - La somme des éléments de la liste
        """
        s = 0
        temp = self.premier
        while temp is not None:
            s = s + temp.valeur
            temp = temp.suivant
        return s
    
    def indice_elt(self, elt):
        """
        elt - élément de même type que les éléments de la liste
        Sortie: int - indice de elt dans la liste, -1 s'il n'est pas présent
        """
        indice = 0
        temp = self.premier
        while temp is not None:
            if temp.valeur == elt:
                return indice
            else:
                indice += 1
                temp = temp.suivant
        return -1
    
    def supprimer_elt_indice(self, k):
        """
        k - int, entier tel que 0 <= k < taille
        Sortie: None - Supprime l'élément d'indice k
        """
        if k==0 or self.est_vide():
            self.supprimer_tete(elt)
        else:
            temp = self.premier
            for i in range(k-1):
                assert temp is not None, "Indice trop grand"
                temp = temp.suivant
                
            temp2 = temp.suivant
            temp.suivant = temp2.suivant
            del temp2
    
    def copie(self):
        """
        Sortie: ListeChainee - Copie de la liste
        """
        result = ListeChainee()
        if not self.est_vide():
            temp = self.premier
            result.inserer_en_dernier(temp.valeur)
            while temp.suivant is not None:
                temp = temp.suivant
                result.inserer_en_dernier(temp.valeur)
        return result
    
    def __add__(self, autreListe):
        """
        autreListe - Objet de type ListeChainee
        Sortie: ListeChainee - Liste constituée des deux précédentes concaténées
        """
        result = self.copie()      
        temp = autreListe.premier
        if not autreListe.est_vide():
            temp = autreListe.premier
            result.inserer_en_dernier(temp.valeur)
            while temp.suivant is not None:
                temp = temp.suivant
                result.inserer_en_dernier(temp.valeur)
        return result

    def queue_distincte(self):
        """
        Renvoie la queue de la liste sous la forme d'une nouvelle liste
        pour éviter les effets de bord
        """
        return self.queue().copie()
        
        
