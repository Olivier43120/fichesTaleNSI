class Element:
    """Type de base pour les éléments de la file"""
    def __init__(self, valeur_element, suivant):
        self.valeur = valeur_element
        self.suivant = suivant


class File:
    """Implémentation d'une file (TAD)"""

    def __init__(self):
        self.premier = None
        self.dernier = None

    def estVide(self):
        """"Renvoie True si et seulement si la file est vide"""
        return self.premier is None

    def enfiler(self, valeur_element):
        """"Enfile un nouvel élément en queue de file."""
        new_elt = Element(valeur_element, None)
        if self.estVide():
            self.premier = new_elt
        else:
            self.dernier.suivant = new_elt
        self.dernier = new_elt

    def defiler(self):
        """"Défile le premier élément de la file."""
        assert not self.estVide(), "La file est vide"

        valeur = self.premier.valeur
        self.premier = self.premier.suivant
        if self.premier is None:
            self.queue = None
        return valeur


    def __repr__(self):
        c = self.premier
        reponse = ""
        if c:
            reponse = str(c.valeur)
            c = c.suivant
        while c:
            reponse = str(c.valeur) + " -> " + reponse
            c = c.suivant
        return reponse

    def __str__(self):
        return self.__repr__()


def josephus(n, k):
    f = File()
    for i in range(1, n+1):
        f.enfiler(i)
    while f.premier.suivant is not None:
        for i in range(k-1):
            personne = f.defiler()
            f.enfiler(personne)
        eliminee = f.defiler()
        print("Personne éliminée :", eliminee)
    return f.defiler()


print("Survivant :", josephus(7, 3))