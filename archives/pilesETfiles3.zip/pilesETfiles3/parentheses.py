class Element:
    """Type de base pour les éléments de la pile"""

    def __init__(self, valeur_element, suivant):
        self.valeur = valeur_element
        self.suivant = suivant

class Pile:
    """Implémentation d'une pile (TAD)"""

    def __init__(self):
        self.sommet = None

    def estVide(self):
        """"Renvoie True si et seulement si la pile est vide"""
        return self.sommet is None

    def empiler(self, valeur_element):
        """"Empile un nouvel élément au sommet de la pile."""
        new_etage = Element(valeur_element, self.sommet)
        self.sommet = new_etage

    def depiler(self):
        """"Dépile le sommet de la pile."""
        assert not self.estVide(), "La pile est vide"

        valeur = self.sommet.valeur
        self.sommet = self.sommet.suivant
        return valeur

    def __repr__(self):
        c = self.sommet
        reponse = ""
        if c:
            reponse = str(c.valeur)
            c = c.suivant
        while c:
            reponse = reponse + "\n" + str(c.valeur)
            c = c.suivant
        return reponse

    def __str__(self):
        return self.__repr__()


def verification(expr):
    p = Pile()
    for element in expr:
        if element == "(":
            p.empiler(element)
        elif element == ")":
            if not p.estVide():
                p.depiler()
            else:
                return False
    return p.estVide()

assert verification("") == True
assert verification("()") == True
assert verification("(())") == True
assert verification("()()") == True
assert verification("(()())") == True

assert verification("(") == False
assert verification(")") == False
assert verification("(()") == False
assert verification("())") == False
assert verification("(()))") == False