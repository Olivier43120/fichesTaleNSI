class Element:
    """Type de base pour les éléments de la pile"""

    def __init__(self, valeur_element, suivant):
        self.valeur = valeur_element
        self.suivant = suivant

class Pile:
    """Implémentation d'une pile (TAD)"""

    def __init__(self):
        self.sommet = None

    def estVide(self):
        """"Renvoie True si et seulement si la pile est vide"""
        return self.sommet is None

    def empiler(self, valeur_element):
        """"Empile un nouvel élément au sommet de la pile."""
        new_etage = Element(valeur_element, self.sommet)
        self.sommet = new_etage

    def depiler(self):
        """"Dépile le sommet de la pile."""
        assert not self.estVide(), "La pile est vide"

        valeur = self.sommet.valeur
        self.sommet = self.sommet.suivant
        return valeur

    def __repr__(self):
        c = self.sommet
        reponse = ""
        if c:
            reponse = str(c.valeur)
            c = c.suivant
        while c:
            reponse = reponse + "\n" + str(c.valeur)
            c = c.suivant
        return reponse

    def __str__(self):
        return self.__repr__()


def NPI(tab):
    p = Pile()

    for element in tab:
        if element not in ["*", "+", "-", "/"]:
            p.empiler(element)
        else:
            a = p.depiler()
            b = p.depiler()
            if element == "*":
                p.empiler(b * a)
            elif element == "+":
                p.empiler(b + a)
            elif element == "-":
                p.empiler(b - a)
            else:
                p.empiler(b / a)
    return p.depiler()
    
# 1. Tests des quatre opérations
assert NPI([3, 4, "+"]) == 7
assert NPI([5, 2, "*"]) == 10
assert NPI([8, 3, "-"]) == 5
assert NPI([10, 2, "/"]) == 5

# 2. Tests avec plusieurs opérations successives
assert NPI([3, 4, "+", 2, "*"]) == 14
assert NPI([5, 2, "*", 3, "+"]) == 13
assert NPI([10, 2, "/", 3, "+"]) == 8

# 3. Tests avec des nombres négatifs
assert NPI([-3, 4, "+"]) == 1
assert NPI([3, 5, "-"]) == -2
assert NPI([-2, 3, "*"]) == -6
assert NPI([6, -2, "/"]) == -3

# 4. Tests avec des résultats décimaux
assert NPI([5, 2, "/"]) == 2.5
assert NPI([7, 2, "/"]) == 3.5
assert NPI([1, 2, "+", 2, "/"]) == 1.5

# 5. Tests avec des expressions plus complexes
assert NPI([2, 3, "+", 4, 5, "+", "*"]) == 45
assert NPI([10, 2, 3, "*", "+"]) == 16
assert NPI([8, 2, "/", 3, "-"]) == 1