from tkinter import * 
from copy import deepcopy

class Element:
    """Type de base pour les éléments de la pile"""

    def __init__(self, valeur_element, suivant):
        self.valeur = valeur_element
        self.suivant = suivant

class Pile:
    """Implémentation d'une pile (TAD)"""

    def __init__(self):
        self.sommet = None

    def estVide(self):
        """"Renvoie True si et seulement si la pile est vide"""
        return self.sommet is None

    def empiler(self, valeur_element):
        """"Empile un nouvel élément au sommet de la pile."""
        new_etage = Element(valeur_element, self.sommet)
        self.sommet = new_etage

    def depiler(self):
        """"Dépile le sommet de la pile."""
        assert not self.estVide(), "La pile est vide"

        valeur = self.sommet.valeur
        self.sommet = self.sommet.suivant
        return valeur

    def __repr__(self):
        c = self.sommet
        reponse = ""
        if c:
            reponse = str(c.valeur)
            c = c.suivant
        while c:
            reponse = reponse + "\n" + str(c.valeur)
            c = c.suivant
        return reponse

    def __str__(self):
        return self.__repr__()



laby1=[[0,1,0,0,0,0],
[0,1,1,1,1,0],
[0,1,0,1,0,0],
[0,1,0,1,1,0],
[0,1,1,0,1,0],
[0,0,0,0,1,0]]



laby2=[[1,1,0,1,0,1,1,0,1,0,1,0,1,0,1,1,1,1],
      [0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0],
      [1,1,1,1,1,0,1,0,1,0,1,0,1,1,1,1,1,1],
      [1,0,1,0,0,0,1,0,1,0,1,0,1,0,0,0,0,0],
      [1,0,1,1,1,1,1,1,1,0,1,1,1,1,0,1,0,1],
      [1,0,0,1,0,1,0,0,1,0,0,0,0,1,1,1,1,1],
      [1,1,0,0,0,1,0,1,1,1,1,1,0,1,0,0,0,0],
      [1,0,1,1,1,1,0,1,0,0,0,1,1,1,1,1,1,1],
      [0,0,0,0,0,1,0,1,0,1,0,0,1,0,1,0,0,1],
      [1,1,1,1,1,1,0,1,0,1,0,1,1,0,1,0,1,1],
      [0,0,0,0,0,1,0,0,0,1,0,0,1,0,1,0,1,0],
      [1,0,1,1,1,1,0,1,1,1,1,1,1,0,1,0,1,0],
      [1,1,1,0,0,0,0,0,1,0,1,0,0,0,0,0,1,0],
      [0,0,1,1,1,1,0,1,1,0,1,0,1,1,1,1,1,1],
      [1,0,1,0,0,1,0,1,0,0,1,0,0,0,0,0,0,1],
      [1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,0,1],
      [1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1],
      [1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1]]


def AfficherLab(laby):
    """
    Affiche le labyrinthe
    parm : list
    return : None (Interface graphique du labyrinthe)
    """
    fenetre = Tk()
    largeur=len(laby[0])
    hauteur=len(laby)
    taille=20
    num_line=0
    num_case=0
    canvas = Canvas(fenetre, width=taille*largeur, height=taille*hauteur, background='white')
    for line in laby:
        num_line=num_line+1
        for case in line:
            num_case=num_case+1
            if case==0:
                canvas.create_rectangle((num_case-1)*taille, (num_line-1)*taille, num_case*taille, num_line*taille, fill='black')
        num_case=0
    canvas.pack()
    fenetre.mainloop()
    
def voisins(T,v):
    lignes = len(T)
    colonnes = len(T)
    V=[]
    i,j=v[0],v[1]
    for  a  in  ( - 1,1):
        if 0<=i+a<lignes:
            if T[i+a][j]==1:
                V.append((i+a,j))
        if 0<=j+a<colonnes:
            if T[i][j+a]==1:
                V.append((i,j+a))
    return V

def parcours(laby,entree,sortie):
    p=Pile()
    v=entree
    laby[entree[0]][entree[1]]=-1
    recherche=True
    while recherche == True:
        vois=voisins(laby,v)
        if vois == []:
            if p.estVide():
                return False
            else:
                v=p.depiler()
        else:
            p.empiler(v)
            v=vois[0]
            laby[v[0]][v[1]]=-1
            if v == sortie:
                p.empiler(v)
                recherche = False
    return p

print(parcours(deepcopy(laby1), (0,1), (5,4)))
print(parcours(deepcopy(laby2), (0,0), (17,17)))

def AfficherSol(laby,pile):
    """
    Affiche le labyrinthe avec la solution
    parm : laby (list)
        pile (list) liste de tuple qui forme la solution
    return : None (Interface graphique du labyrinthe et de sa solution)
    """
    fenetre = Tk()
    largeur=len(laby[0])
    hauteur=len(laby)
    taille=20
    num_line=0
    num_case=0
    canvas = Canvas(fenetre, width=taille*largeur, height=taille*hauteur, background='white')
    for line in laby:
        num_line=num_line+1
        for case in line:
            num_case=num_case+1
            if case==0:
                canvas.create_rectangle((num_case-1)*taille, (num_line-1)*taille, num_case*taille, num_line*taille, fill='black')
        num_case=0
    while not pile.estVide():
        elt=pile.depiler()
        canvas.create_rectangle(taille*elt[1]+taille//3, taille*elt[0]+taille//3, taille*elt[1]+taille-taille//3, taille*elt[0]+taille-taille//3, fill='red', width=0)
    
    canvas.pack()
    fenetre.mainloop()

pile1=parcours(laby1,(0,1),(5,4))
AfficherSol(laby1,pile1)  

pile2=parcours(laby2,(0,0),(17,17))
AfficherSol(laby2,pile2)