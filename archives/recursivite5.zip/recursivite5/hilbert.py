from turtle import *

def hilbert(angle,n):
    """ Dessine la courbe de Hilbert d'ordre n """
    if n == 0:
        return

    # à vous !

    return

# Test
speed('fastest')
width(3)
up()
goto(-300,300)
down()
n = 4
longueur = 40
hilbert(90,n)
done()
