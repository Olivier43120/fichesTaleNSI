from turtle import *

def triangle(l,n):
    """ Dessine le triangle de Sierpinski d'ordre n ('l' est une longueur) """
    if n==0:
        return

    for __ in range(3):
        ...
        ...
        ...

    return

# Test
speed('fastest')
hideturtle()
width(3)
up()
goto(-300,-250)
down()
triangle(600,3)
done()
