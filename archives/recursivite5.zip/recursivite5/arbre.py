from turtle import *

def arbre(l,n,theta = 30):
    """ Dessine un arbre d'ordre n ('l' est une longueur) """ 
    if n==0:
        return

    P = position() # position() est une fonction de Turtle, elle renvoie les coordonnées actuelles de la tortue. On les stocke dans la variable P
    # Cette affectation permettra de revenir exactement à cet endroit après avoir dessiné une branche.
    setheading(-90-theta)    # pour pivoter d'un certaine angle tehta par rapport à l'horizontale
    forward(l) # on avance
    arbre(...,...) # on fait un appel récursif pour provoquer un arbre plut petit
    goto(P) # on revient à l'embranchement de départ
    setheading(...)    # on s'occupe de l'autre branche
    forward(l)
    arbre(...,...)
    goto(P) # on revient à l'zmbranchement initial

    return

# Test
speed('fastest')
width(3)
up()
goto(0,300)
down()
arbre(300,6)
done()
