from turtle import *


def koch(l,n):
    """ Trace le flocon de Koch d'ordre n ('l' est une longueur) """
    if n==0:
        forward(l) 
        return
    koch(...,...)
    left(...)
    koch(...,...)
    # à compléter
    return

# Test
# speed('fastest')
# width(2)
# up()
# goto(-400,-200)
# down()
# koch(800,4)
# done()
