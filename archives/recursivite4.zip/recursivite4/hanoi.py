def affichage(tours) :
    d = len(tours['depart'])
    i = len(tours['intermediaire']) 
    a = len(tours['arrivee']) 
    hauteur = max(d, i, a)
    
    for h in range(hauteur, 0, -1) :
        if d >= h : 
            print( tours['depart'][h-1], end=' ')
        else : 
            print(' ', end=' ')
        if i >= h : 
            print( tours['intermediaire'][h-1], end=' ') 
        else : 
            print(' ', end=' ')
        if a >= h :
            print( tours['arrivee'][h-1])
        else : 
            print(' ')
    
    print('\u2AE0 \u2AE0 \u2AE0') 
    print('---------------------------------------------------------------')

def hanoi(n,dep='depart',inter='intermediaire',arr='arrivee'): 
    if n==0:
        return ...
    else:
        hanoi(...,...,...,...)
        print("Deplacer le disque {} de la tige {} vers la tige {}.".format(n,dep,arr)) 
        anneau_deplace = tours[dep].pop()
        tours[arr].append(anneau_deplace) 
        affichage(tours)
        hanoi(...,...,...,...)
        
n=4
tours = dict()
tours['depart'] = [ j for j in range(n,0,-1) ] 
tours['intermediaire'] = []
tours['arrivee'] = []
hanoi(n)