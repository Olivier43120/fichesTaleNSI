def reine(q,j):
    if j == len(q):
        print(q)
    for i in range(len(q)):
        legal = True
        for k in range(j):
            if q[k] in ..........:
                legal = ...
                break
        if ......:
            q[j] = ......
            reine(...,...)

reine([None]*8,0)