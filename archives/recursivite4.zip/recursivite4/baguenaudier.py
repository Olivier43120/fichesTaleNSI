def peut_jouer(etat, j):
    """Renvoie True si on a le droit de jouer sur la case j."""
    if j == 1:
        return ...
    if etat[j - 2] ......:          # la case j-1 doit porter un pion
        return False
    for c in etat[:j - 2]:        # rien avant la case j-1
        .........:
            ......
    return True

def poser(etat, j):
    assert ... == ..., print("la case ",j," est déjà occupée")
    assert ......, print("coup interdit en case ",j)
    etat[......] = ...
    print("on pose un pion en case ",j)

def enlever(etat, j):
    assert ... == ..., print("la case ",j," est vide")
    assert ......, print("coup interdit en case ",j)
    etat[......] = ...
    print("on enlève le pion de la case ",j)


def vider(etat, n):
    if n == 0:
        return
    elif n == 1:
        enlever(etat, ...)
    elif n == 2:
        enlever(etat, ...)
        enlever(etat, ...)
    else:
        ...(etat, ...)      # cases 1..n-2 vides ; n-1 et n restent pleines
        ...(etat, ...)        # légal : case n-1 pleine, rien avant elle
        ...(etat, ...)    # on remplit à nouveau les n-2 premières cases
        ...(etat, ...)      # puis on vide tout ce qui reste (1..n-1)

def remplir(etat, n):
    if n == 0:
        return
    elif n == 1:
        poser(etat, ...)
    elif n == 2:
        poser(etat, ...)
        poser(etat, ...)
    else:
        ...(etat, ...)    # cases 1..n-1 pleines
        ...(etat, ...)      # cases 1..n-2 vides ; n-1 reste pleine
        ...(etat, ...)          # légal : case n-1 pleine, rien avant elle
        ...(etat, ...)    # on remplit à nouveau les n-2 premières cases


if __name__ == "__main__":
    n = 4
    etat = [1] * n
    print("Baguenaudier à ",n," cases, état initial : ",etat,"\n")
    vider(etat, n)
    print("\nÉtat final : ",etat)