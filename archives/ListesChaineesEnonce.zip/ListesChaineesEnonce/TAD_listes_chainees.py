class Maillon:
    """
    Implémentation d'un Maillon,
    nécessaire à l'implémentation d'une liste chaînée
    """

    def __init__(self, valeur=None, suivant=None):
        """
        Initialisation d'un maillon
        """
        pass

    def __repr__(self):
        """
        Sortie: str - Chaîne d'affichage du maillon.
        """
        pass


class ListeChainee:
    """
    Implémentation d'une liste chaînée
    """

    def __init__(self):
        """
        Initialisation d'une liste chaînée.
        """
        pass

    def est_vide(self):
        """
        Booléen indiquant si la liste chaînée est vide
        """
        pass

    def inserer_en_tete(self, elt):
        """
        Insère un élément en tête de liste.
        """
        pass

    def tete(self):
        """
        Renvoie la valeur de l'élément en tête de liste.
        """
        pass

    def queue(self):
        """
        Renvoie la liste située en queue (pas le maillon !)
        sous la forme d'une nouvelle liste.
        Attention aux effets de bord
        """
        pass

    def __repr__(self):
        """
        Sortie: str - Chaîne d'affichage de la liste.
        """
        pass

    def vider(self):
        """"
        Supprime tous les éléments de la liste.
        Ne renvoie rien.
        """
        pass

    def tab_to_liste(self, tab):
        """
        Insère les éléments de tab dans l'objet ListeChainee
        """
        pass
    
    def inserer_en_dernier(self, elt):
        """
        Insère l'élément en fin de liste chaînée
        """
        pass
    
    def supprimer_premier(self):
        """
        Sortie: None - Supprime le premier élément de la liste
        """
        pass
    
    def supprimer_dernier(self):
        """
        Sortie: None - Supprime le dernier élément de la liste
        """
        pass
    
    def __len__(self):
        """
        Sortie: int - Nombre d'éléments de la liste
        """
        pass
    
    def elt_indice(self, k):
        """
        k - int, entier tel que 0 <= k < taille
        Sortie: élément d'indice k de la liste
        """
        pass
    
    def modifier_elt_indice(self, k, elt):
        """
        k - int, entier positif inférieur au nombre d'éléments de la liste
        elt - un élément de même type que ceux de la liste
        Sortie: None - Modification de la valeur d'indice k de la liste
        """
        pass
    
    def insere_position(self, k, elt):
        """
        k - int, entier positif inférieur au nombre d'éléments de la liste
        elt - un élément de même type que ceux de la liste
        Sortie: None - Insertion de elt à l'indice k
        """
        pass
    
    def somme(self):
        """
        Sortie: int - La somme des éléments de la liste
        """
        pass
    
    def indice_elt(self, elt):
        """
        elt - élément de même type que les éléments de la liste
        Sortie: int - indice de elt dans la liste, -1 s'il n'est pas présent
        """
        pass
    
    def supprimer_elt_indice(self, k):
        """
        k - int, entier tel que 0 <= k < taille
        Sortie: None - Supprime l'élément d'indice k
        """
        pass
    
    def copie(self):
        """
        Sortie: ListeChainee - Copie de la liste
        """
        pass
    
    def __add__(self, autreListe):
        """
        autreListe - Objet de type ListeChainee
        Sortie: ListeChainee - Liste constituée des deux précédentes concaténées
        """
        pass

    def queue_distincte(self):
        """
        Renvoie la queue de la liste sous la forme d'une nouvelle liste
        pour éviter les effets de bord
        """
        pass
        
        





