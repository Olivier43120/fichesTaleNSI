# recherche dichotomique itérative

def recherche_dichotomique_iter(v, T):
    debut = 0
    fin = len(T) - 1
    while ...... <= ......: # condition d'arêt
        m = ...... # calcul de la position du milieu
        if v == T[m]:
            return ......
        if v > T[m]:
            debut = ......
        else:
            fin = ......
    return False

assert recherche_dichotomique_iter(32, [2, 3, 9, 10, 16, 30, 32, 37, 50, 89]) == True
assert recherche_dichotomique_iter(20, [2, 3, 9, 10, 16, 30, 32, 37, 50, 89]) == False


# recherche dichotomique récursive

def recherche_dichotomique_recur(v, T, debut = 0, fin=None):
    if fin is None:
        fin = len(T) - 1
    if debut > fin:
        return ......
    milieu = ...... # calcul de la position du milieu
    if   T[milieu] > v:
        return recherche_dichotomique_recur(..., ..., ..., ...)
    elif T[milieu] < v:
        return recherche_dichotomique_recur(..., ..., ..., ...)
    else:
        return True

assert recherche_dichotomique_recur(32, [2, 3, 9, 10, 16, 30, 32, 37, 50, 89]) == True
assert recherche_dichotomique_recur(20, [2, 3, 9, 10, 16, 30, 32, 37, 50, 89]) == False
