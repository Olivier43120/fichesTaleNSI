# Méthode itérative

def conv2to10_iter(chaine):
    res = ... # intialisation
    for k in range(len(chaine)):
        res = ... + ... * ......
    return res

assert conv2to10_iter("10111") == 23


# Méthode récursive

def conv2to10_recur(chaine):
    if chaine == "":
        return ...
    else:
        return conv2to10_recur(............) # Appel récursif

assert conv2to10_recur("10111") == 23
