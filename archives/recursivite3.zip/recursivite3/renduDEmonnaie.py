# Méthode itérative

# Notre système monnétaire rangé dans l'ordre croissant
L = [1, 2, 5, 10, 20, 50, 100, 200]

def rendu_iter(somme):
    monnaie = []
    position = ......  # on se positionne en dernière position, la devise qui a la plus grande valeur
    while somme ......: # Condition d'arrêt
        while L[position] ......: # condition qui permet de savoir si on utilise toujours la même piece
            somme  = ...... 
            monnaie.append(......)
        position ...... # On change de pièce, on passe à la devise imédiatement inférieure
    return monnaie
        
assert rendu_iter(287) == [200, 50, 20, 10, 5, 2]


# Méthode récursive

# Notre système monnétaire
L = [1, 2, 5, 10, 20, 50, 100, 200]

def rendu_recur(somme, monnaie = [], pos = len(L) - 1):
    if somme ......: # Cas de base
        return monnaie
    else:
        if L[pos] <= somme:
            return rendu_recur(......, ...... , ......)
        else:
            return rendu_recur(......, ......, ......)
        
        
assert rendu_recur(287) == [200, 50, 20, 10, 5, 2]
