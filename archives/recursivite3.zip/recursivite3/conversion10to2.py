# Méthode itérative

def conv10to2_iter(nb):
    chaine = ""
    while nb != 0:
        chaine = ...... + ......
        nb = ......
    return chaine

assert conv10to2_iter(200) == '11001000'


# Méthode récursive

def conv10to2_recur(nb):
    if nb == 0:
        return ......
    else:
        return ............ # Appel récursif à cette ligne
    
assert conv10to2_recur(200) == '11001000'
