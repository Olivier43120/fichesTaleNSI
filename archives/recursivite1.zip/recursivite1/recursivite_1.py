# Exercice 1
def u_iterative(n):
    # à vous !
    
assert u_iterative(0) == 5
assert u_iterative(1) == 7
assert u_iterative(2) == 31
assert u_iterative(3) == 107
assert u_iterative(4) == 383

def u_recursive(n):
    # à vous !
    
assert u_recursive(0) == 5
assert u_recursive(1) == 7
assert u_recursive(2) == 31
assert u_recursive(3) == 107
assert u_recursive(4) == 383

# Exercice 2
def rebours(n): 
    """
    entree : n de type int
    sortie : affichage des entiers n, n-1, n-2, ...1
    """
    # à vous !
    
# tests laissés à votre discrétion

# Exercice 3
def somme(n):
    """
    entree : n de type int
    sortie : la somme 1+2+3+...+n
    """
    # à vous !
    
assert somme(5) == 15
assert somme(10) == 55

# Exercice 4
from turtle import *

def escalier(n):
    if n <= 0:
        return
    forward(10)
    right(90)
    forward(10)
    left(90)
    escalier(n - 1)

escalier(5)

# Exercice 5
def somme_liste(L): 
    """
    entree : une liste L de nombres
    sortie : la somme des nombres de cette liste.
    """
    # à vous !
    
assert somme_liste([8,3,1,4]) == 16
assert somme_liste([]) == 0
assert somme_liste([7]) == 7
assert somme_liste([2,8,4,3,9,1,3]) == 30

# Exercice 6
def produit_liste(L): 
    """
    entree : une liste L de nombres
    sortie : le produit des nombres de cette liste.
    """
    # à vous !
    
assert produit_liste([8,3,1,4]) == 96
assert produit_liste([]) == 1
assert produit_liste([7]) == 7
assert produit_liste([2,8,4,3,9,1,3]) == 5184

# Exercice 7
def min_liste(L):
    """
    entree : une liste L de nombres
    sortie : la valeur de l'élément minimum de cette liste.
    """
    # à vous !
    
assert min_liste([8,3,1,4]) == 1
assert min_liste([7]) == 7
assert min_liste([12,8,4,3,9,7,9]) == 3

# Exercice 8
def test_ordre_liste(L): 
    """
    entree : une liste L de nombres
    sortie : True si la liste est ordonnee croissante, False sinon 
    """
    # à vous !
    
assert test_ordre_liste([8,13,21,24]) == True
assert test_ordre_liste([7]) == True
assert test_ordre_liste([12,18,24,43,39,47,49]) == False

# Exercice 9
def presence(x,L): 
    """
    entree : Une liste L de nombres et un nombre x 
    sortie : False si x n'est pas dans L, True sinon 
    """
    # à vous !
    
assert presence(7, [6,9,2,3,7,1]) == True
assert presence(7, []) == False

# Exercice 10
def indice(x, L):
    """
    entree : Une liste L de nombres et un nombre x
    sortie : -1 si x n'est pas dans L, l'indice d'une occurence de x dans L lorsque x est présent dans L
    """
    if L == []:
        return ...
    if L[0] == x:
        return ...

    i = indice(x, L[1:])
    if i == ...:
        return ...
    return ...

# Exercice 11
def nb_occurences(x,L):
    """
    entree : Une liste L de nombres et un nombre x
    sortie : le nombre d'occurences de x dans la liste L
    """
    # à vous !
    
assert nb_occurences(7, [3,9,7,2,1,7,4,9]) == 2
assert nb_occurences(3, []) == 0
assert nb_occurences(5, [2,3,9,7,2,1,10,2]) == 0
assert nb_occurences(2, [2,3,9,7,2,1,10,2]) == 3

# Exercice 12
def est_palindrome(chaine): 
    """
    entree : un mot (type str)
    sortie : True si l'entrée est un palindrome, False sinon
    """
    # à vous !
    
assert est_palindrome('radar') == True
assert est_palindrome('BoB') == True
assert est_palindrome('Radar') == False

# Exercice 13
def sens_inverse(chaine): 
    """
    entree : un mot (type str)
    sortie : le même mot écrit à l'envers
    """
    # à vous !
    
assert sens_inverse('Bonjour') == 'ruojnoB'
assert sens_inverse('Radar') == 'radaR'

# Exercice 14
def estPuissanceDe2(n): 
    """
    entree : Un entier naturel n non nul
    sortie : True si n est une puissance de 2, False sinon
    """
    # à vous !
    
assert estPuissanceDe2(1024) == True
assert estPuissanceDe2(48) == False
assert estPuissanceDe2(1) == True

# Exercice 15
def estMultipleDe9(nb):
    """
    entree : Un entier naturel non nul
    sortie : True si c'est un multiple de 9, False sinon
    """
    # à vous !
    
assert estMultipleDe9(23463) == True
assert estMultipleDe9(9) == True
assert estMultipleDe9(23451) == False
