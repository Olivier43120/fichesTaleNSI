class Livre():
    def __init__(self,titre, auteur, prix):
        assert isinstance(prix,int) or isinstance(prix,float)
        self.titre = titre
        self.auteur = auteur
        self.prix = prix
        
    def est_titre(self,price):
        pass
    
    def est_moins_cher(self, other):
        pass
    
    def __del__(self):
        pass
        
d = Livre("a", "b", 12)
e = Livre("b", "c", 14)
assert d.est_titre("a")
assert not d.est_titre("b")
assert d.est_moins_cher(e)
assert not e.est_moins_cher(d)
del(d)