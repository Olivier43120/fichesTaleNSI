class Angle:
    def __init__(self,mesure = 0):
        assert ......
        pass
        
    def __repr__(self):
        pass
        
    def __str__(self):
        pass
    
    def normaliser(self):
        pass
    
    def get_angle(self):
        pass
    
    def set_angle(self,newValeur):
        pass
        
    def __add__(self,other):
        pass