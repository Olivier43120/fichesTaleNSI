COULEURS = ["noir", "marron", "rouge", "orange", "jaune", "vert", "bleu", "violet", "gris", "blanc"]

class Resistor:
    def __init__(self, resistance):
        pass
    
    def getResistance(self):
        pass
    
    def approche(self):
        pass
        
        # Arrondi aux 2 premiers chiffres
        pass
    
    def __repr__(self):
        pass

    def __str__(self):pass

    def __sub__(self, autre):
        pass
    
    def __floordiv__(self, autre):
        pass