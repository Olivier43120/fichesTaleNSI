class Duree:
    def __init__(self, h=0, m=0, s=0):
        pass

    def normaliser(self):
        pass

    def __str__(self):
        pass

    def __repr__(self):
        pass

    def __add__(self, autre):
        pass