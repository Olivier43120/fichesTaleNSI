class Intervalle:
    def __init__(self,borne_inf,borne_sup):
        assert ......
        assert ......
        self.borne_inf = ......
        self.borne_sup = ......
        
    def est_vide(self):
        pass
    
    def __repr__(self):
        pass
    
    def __str__(self):
        pass
    
    def amplitude(self):
        pass
        
    def __contains__(self,valeur):
        pass
    
    def __eq__(self,autreIntervalle):
        pass
    
    def __le__(self,autreIntervalle):
        pass
    
    def intersection(self, autreIntervalle):
        pass
        
    def union(self, autreIntervalle):
        pass
    